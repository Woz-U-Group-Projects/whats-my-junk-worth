import React from 'react';
import Header from '../components/Header';

const Mine = () => <Header title="Mine" />

export default Mine;