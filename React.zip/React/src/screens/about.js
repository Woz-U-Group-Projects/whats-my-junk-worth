import React from 'react';
import Header from '../components/Header';

const About = () => (
    <Header title="About" />
);


export default About;